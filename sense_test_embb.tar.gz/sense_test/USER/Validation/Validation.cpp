/**
* @file Validation.cpp
* @brief 
* @author 交控研究院
* @date Sep 27, 2022
* @version V1.1
* @copyright TCT
* @par 修改日志
* <table>
* <tr><th>Date        <th>Version  <th>Author     <th>Description
* <tr><th>Sep 27, 2022     <th>V1.0     <th>交控研究院   <th>创建文件
* </table>
*/
#include "Validation.h"
#include <iostream>

using namespace std;

/**
* @brief 	获取验证结果
* @param
* @return 
*/
INT16 validation_type::get_result(UINT8* pbuf, UINT16 buf_size, UINT16* psize)
{
	INT16 len = 0;



	return len;
}
