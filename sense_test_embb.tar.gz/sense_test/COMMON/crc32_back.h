/*
 * crc32_back.h
 *
 *  Created on: 2022年10月13日
 *      Author: bg
 */

#ifndef CRC32_BACK_H_
#define CRC32_BACK_H_


unsigned int getCRC32(char* bytes,int index,int length);


#endif /* CRC32_BACK_H_ */
