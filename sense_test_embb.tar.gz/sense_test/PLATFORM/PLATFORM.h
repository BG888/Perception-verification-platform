/*
 * PLATFORM.h
 *
 *  Created on: Sep 23, 2022
 *      Author: tct
 */

#ifndef PLATFORM_H_
#define PLATFORM_H_

#include "Protocol/tcp/tcpserver.h"
#include "mysql_op/mysql_op.h"
#include "xpack/json.h"


#endif /* PLATFORM_H_ */
